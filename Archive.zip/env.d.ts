declare namespace NodeJS {
  interface ProcessEnv {
    NEXT_PUBLIC_NEST_API_BASE?: string
    NEXT_PUBLIC_BASE_URL?: string
  }
}
